import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

excel_file = 'Railway Statistics Summary from 2002-03 to 2014-15.xls'
file = pd.read_excel(excel_file)

# Get gross Earnings by splicing
grossEarnings = file.iloc[5][3:]

noKilled = file.iloc[42][3:]

fig = plt.figure()

plt.scatter(grossEarnings,noKilled)

fig.suptitle('Gross Earnings vs Number of Deaths in Railways from 2002 to 2015', fontsize=20)

plt.xlabel('Gross Earnings', fontsize=18)
plt.ylabel('Number of Deaths', fontsize=18)

z = np.polyfit(list(grossEarnings), list(noKilled), 1)
p = np.poly1d(z)
plt.plot(grossEarnings,p(grossEarnings),"r--")



plt.show()