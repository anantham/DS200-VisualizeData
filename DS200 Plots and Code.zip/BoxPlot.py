import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

excel_file = 'weekly retail price of milk upto 2012 clean.xls'
file = pd.read_excel(excel_file)
price = list(file["Price"])
price = [price for price in price if str(price) != 'nan']

print(min(price))

fig = plt.figure()
plt.boxplot(price)
fig.suptitle('Distribution of Milk Prices from 2003 to 2012', fontsize=20)
plt.xlabel("Milk", fontsize=18)
plt.ylabel("Retail price of 1 lt milk in Rs", fontsize=18)
plt.show()