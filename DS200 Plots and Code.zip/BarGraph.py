import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

excel_file = 'State wise fiscal deficit data from 2007 to 2014.xls'
file = pd.read_excel(excel_file)

# Get deficit values by splicing
deficit = file.iloc[20][2:9]

fig = plt.figure()

ax = deficit.plot(kind = 'bar')
fig.suptitle('Fiscal Deficit of Kerala in Rs. Crore from 2007 to 2014', fontsize=20)

ax.set_xlabel("Years", fontsize=18)
ax.set_ylabel("Fiscal Deficit in Rs. Crore", fontsize=18)
plt.show()